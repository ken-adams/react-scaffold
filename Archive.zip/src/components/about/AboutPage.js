import React from 'react';


class AboutPage extends React.Component {

    render() {

        return (
            <div className="jumbotron">
                <h1>About Page</h1>
                <p>This is About page</p>
            </div>
        );
    }
}

export default AboutPage;