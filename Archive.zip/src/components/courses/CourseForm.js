import React, {PropTypes} from 'react';
import TextInput from '../common/TextInput';
import SelectInput from '../common/SelectInput';

const CourseFrom = ({course, allAuthors, onSave, onChange, loading, errors}) => {

    return(
        <form>
            <h1>Manage Course</h1>

            <TextInput
                name="title"
                label="Title"
                value={course.title}
                onChange={onChange}
                errror={errors.title}
            />

            <SelectInput
                name="authorId"
                label="Author"
                value={course.authorId}
                defaultOption="Select author"
                options={allAuthors}
                onChange={onChange} error={errors.title}
            />

            <TextInput
                name="category"
                label="Category"
                value={course.category}
                onChange={onChange}
                errror={errors.title}
            />

            <TextInput
                name="length"
                label="Length"
                value={course.length}
                onChange={onChange}
                errror={errors.title}
            />

            <input
                type="submit"
                disabled={loading}
                value={loading ? 'Saving ...' : 'Save'}
                className="btn btn-primary"
                onClick={onSave}
            />
        </form>
    );
};

CourseFrom.propTypes = {
    course: React.PropTypes.object.isRequired,
    allAuthors: React.PropTypes.array,
    onSave: React.PropTypes.func.isRequired,
    onChange: React.PropTypes.func.isRequired,
    loading: React.PropTypes.bool,
    errors: React.PropTypes.object
};

export default CourseFrom;