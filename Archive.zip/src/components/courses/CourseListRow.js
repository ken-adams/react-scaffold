import React, {PropTypes} from 'react';
import {Link} from 'react-router';
import {connect} from 'react-redux';
import * as courseActions from "../../actions/courseActions";
import {bindActionCreators} from "redux";
import toastr from 'toastr';

class CourseListRow extends React.Component {

    constructor(props, context) {
        super(props, context);
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick(event) {
        this.props.actions.deleteCourse(event.target.value).then(
            toastr.success('Course successfully deleted!')
        );
    }

    render() {
        const course = this.props.course;
        return (
            <tr>
                <td><a href={course.watchHref} target="_blank">Watch</a></td>
                <td>
                    <button value={course.id} onClick={this.handleClick} className="btn btn-primary">Delete</button>
                </td>
                <td><Link to={'/course/' + course.id}>{course.title}</Link></td>
                <td>{course.authorId}</td>
                <td>{course.category}</td>
                <td>{course.length}</td>
            </tr>
        );
    }
}

CourseListRow.propTypes = {
    course: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

function mapStateToProps(state, ownProps) {
    return {
        courses: state.courses
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(courseActions, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CourseListRow);
