import React, {PropTypes} from 'react';
import {Link, IndexLink} from 'react-router';

const Header = ({coursesCount}) => {
    return (
      <nav>
          <IndexLink to="/" activeClassName="active">Home Link</IndexLink>
          {" | "}
          <Link to="/courses" activeClassName="active">Courses</Link> ({coursesCount})
          {" | "}
          <Link to="/about" activeClassName="active">About Link</Link>
      </nav>
    );
};

Header.propTypes = {
    coursesCount: PropTypes.number.isRequired
};

export default Header;